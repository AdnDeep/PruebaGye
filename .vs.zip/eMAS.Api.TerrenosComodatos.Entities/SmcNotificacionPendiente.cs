﻿using System;
using System.Collections.Generic;

#nullable disable

namespace eMAS.Api.TerrenosComodatos.Entities
{
    public partial class SmcNotificacionPendiente
    {
        public SmcNotificacionPendiente()
        {
        }
        public string Descripcion { get; set; }
    }
}
