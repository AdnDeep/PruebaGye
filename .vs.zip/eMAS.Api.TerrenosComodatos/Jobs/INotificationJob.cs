﻿

namespace eMAS.Api.TerrenosComodatos
{
    public interface INotificationTramiteOficioJob
    {
        void Execute();
    }
}
