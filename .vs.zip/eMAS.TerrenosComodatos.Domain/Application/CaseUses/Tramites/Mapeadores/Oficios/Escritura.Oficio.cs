﻿using eMAS.TerrenosComodatos.Domain.DTOs;
using System.Collections.Generic;

namespace eMAS.TerrenosComodatos.Domain.Application
{
    public partial class MapeadoresTramite
    {
        public void MapearDataEscrituraOficio(ref OficioTramiteEditViewModel model)
        {
            
        }
    }
}
