﻿
namespace eMAS.TerrenosComodatos.Domain.Constantes
{
    public class AppConst
    {
        public const string formatoFechaDefecto = "dd/MM/yyyy";
        public const short anioMinimoMimg = 1992;
        public const string EntidadAnexo = "Anexo";
        public const string EntidadObservacion = "Observacion";
        public const string EntidadOficio = "Oficio";
        public const string EntidadTopografia = "Topografia";
    }
}
