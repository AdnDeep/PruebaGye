﻿using System.Collections.Generic;

namespace eMAS.Api.TerrenosComodatos.ViewModel
{
    public class UsuarioPerfilOpcion
    {
        public string NombrePerfil { get; set; }
        public string NombreOpcion { get; set; }
    }
}
