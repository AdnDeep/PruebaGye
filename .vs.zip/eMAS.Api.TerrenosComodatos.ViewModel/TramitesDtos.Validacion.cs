﻿namespace eMAS.Api.TerrenosComodatos.ViewModel
{
    public class TramiteDataValidationEscritura
    {
        public short idtramite { get; set; }
        public short idbeneficiario { get; set; }
        public short iddireccion { get; set; }
        public short idestado { get; set; }
        public short idtipocontrato { get; set; }
    }
}
