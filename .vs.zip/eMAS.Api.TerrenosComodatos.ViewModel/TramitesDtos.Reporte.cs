﻿
using System;
using System.Collections.Generic;

namespace eMAS.Api.TerrenosComodatos.ViewModel
{
    public class TramiteReportServerViewModel 
    {
        public string fileName { get; set; }
        public string contentReport { get; set; }
    }
}
